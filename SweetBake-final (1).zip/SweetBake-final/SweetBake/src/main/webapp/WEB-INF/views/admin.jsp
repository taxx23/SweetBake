<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="jakarta.tags.core"%>
<%@include file="header.jsp"%>

<section class="section">
    <div class="container">
        <p class="small-caps">Administrator</p>
        <h1 class="title">Admin dashboard</h1>

        <c:if test="${not empty message}">
            <div class="alert alert-success">${message}</div>
        </c:if>
        <c:if test="${not empty error}">
            <div class="alert alert-danger">${error}</div>
        </c:if>

        <div class="white-box mb-4">
            <h2 class="item-name mt-0">Desserts</h2>
            <c:forEach var="category" items="${categories}">
                <form action="admin" method="post" class="row g-2 mb-2">
                    <input type="hidden" name="action" value="updateCategory">
                    <input type="hidden" name="categoryId" value="${category.categoryId}">
                    <div class="col-md-3">
                        <input type="text" name="name" value="${category.name}" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <input type="text" name="description" value="${category.description}" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="image" value="${category.image}" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-olive w-100">Save</button>
                    </div>
                </form>
            </c:forEach>
        </div>

        <div class="white-box mb-4">
            <h2 class="item-name mt-0">Options and prices</h2>
            <c:forEach var="category" items="${categories}">
                <p class="form-label mt-3">${category.name}</p>
                <c:forEach var="option" items="${options}">
                    <c:if test="${option.categoryId == category.categoryId}">
                        <div class="d-flex gap-2 mb-2">
                            <form action="admin" method="post" class="d-flex gap-2 flex-grow-1">
                                <input type="hidden" name="action" value="updateOption">
                                <input type="hidden" name="optionId" value="${option.optionId}">
                                <span class="option-type">${option.optionType}</span>
                                <input type="text" name="name" value="${option.name}" class="form-control" required>
                                <input type="number" name="price" value="${option.price}" min="0" step="0.01" class="form-control price-input" required>
                                <button type="submit" class="btn btn-olive btn-sm">Save</button>
                            </form>
                            <form action="admin" method="post">
                                <input type="hidden" name="action" value="removeOption">
                                <input type="hidden" name="optionId" value="${option.optionId}">
                                <button type="submit" class="btn btn-outline-danger btn-sm">Remove</button>
                            </form>
                        </div>
                    </c:if>
                </c:forEach>
            </c:forEach>
        </div>

        <div class="white-box mb-4 table-responsive">
            <h2 class="item-name mt-0">Bakers</h2>
            <c:if test="${empty bakers}">
                <p class="small-text mb-0">There are no baker accounts.</p>
            </c:if>
            <c:if test="${not empty bakers}">
                <table class="table align-middle">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th></th>
                    </tr>
                    <c:forEach var="baker" items="${bakers}">
                        <tr>
                            <td><c:out value="${baker.fullName}"/></td>
                            <td><c:out value="${baker.email}"/></td>
                            <td><c:out value="${baker.phone}"/></td>
                            <td>
                                <form action="admin" method="post">
                                    <input type="hidden" name="action" value="removeBaker">
                                    <input type="hidden" name="userId" value="${baker.userId}">
                                    <button type="submit" class="btn btn-outline-danger btn-sm">Remove</button>
                                </form>
                            </td>
                        </tr>
                    </c:forEach>
                </table>
            </c:if>
        </div>

        <div class="white-box mb-4 table-responsive">
            <h2 class="item-name mt-0">Reviews</h2>
            <c:if test="${empty reviews}">
                <p class="small-text mb-0">There are no reviews yet.</p>
            </c:if>
            <c:if test="${not empty reviews}">
                <table class="table align-middle">
                    <tr>
                        <th>Customer</th>
                        <th>Rating</th>
                        <th>Comment</th>
                        <th></th>
                    </tr>
                    <c:forEach var="review" items="${reviews}">
                        <tr>
                            <td><c:out value="${review.customerName}"/></td>
                            <td class="stars"><c:forEach begin="1" end="${review.rating}">&#9733;</c:forEach></td>
                            <td><c:out value="${review.comment}"/></td>
                            <td>
                                <form action="admin" method="post">
                                    <input type="hidden" name="action" value="deleteReview">
                                    <input type="hidden" name="reviewId" value="${review.reviewId}">
                                    <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    </c:forEach>
                </table>
            </c:if>
        </div>

        <div class="row g-4">
            <div class="col-md-6">
                <form action="admin" method="post" class="white-box h-100">
                    <h2 class="item-name mt-0">Add option</h2>
                    <input type="hidden" name="action" value="addOption">
                    <label class="form-label">Dessert</label>
                    <select name="categoryId" class="form-select mb-2">
                        <c:forEach var="category" items="${categories}">
                            <option value="${category.categoryId}">${category.name}</option>
                        </c:forEach>
                    </select>
                    <label class="form-label">Type</label>
                    <select name="optionType" class="form-select mb-2">
                        <option>SIZE</option>
                        <option>FLAVOR</option>
                        <option>FILLING</option>
                        <option>FROSTING</option>
                        <option>SAUCE</option>
                        <option>TOPPING</option>
                    </select>
                    <label class="form-label">Name</label>
                    <input type="text" name="name" class="form-control mb-2" required>
                    <label class="form-label">Price (AED)</label>
                    <input type="number" name="price" min="0" step="0.01" class="form-control mb-3" required>
                    <button type="submit" class="btn btn-olive">Add option</button>
                </form>
            </div>

            <div class="col-md-6">
                <form action="admin" method="post" class="white-box h-100">
                    <h2 class="item-name mt-0">Add baker</h2>
                    <input type="hidden" name="action" value="addBaker">
                    <label class="form-label">Full name</label>
                    <input type="text" name="fullName" class="form-control mb-2" required>
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control mb-2" required>
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control mb-2">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" minlength="8" class="form-control mb-3" required>
                    <button type="submit" class="btn btn-olive">Add baker</button>
                </form>
            </div>
        </div>
    </div>
</section>

<%@include file="footer.jsp"%>
